package com.example.nilufer.dataekleme;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SifreIslemleri extends AppCompatActivity {
    EditText tID,tName,tEmail,tPassword,tConfirmPassword;
    Button btnUpdate,btnCancel;
    DatabaseReference databaseReference;
    private TextView result;
    Modul module;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        result=(TextView)findViewById(R.id.textView2);
        tName=(EditText) findViewById(R.id.tName);
        tPassword=(EditText) findViewById(R.id.tPassword);
        tConfirmPassword=(EditText) findViewById(R.id.tConfirmPassword);
        btnUpdate=(Button) findViewById(R.id.btnUpadate);
        btnCancel= (Button) findViewById(R.id.btnCancel) ;
        databaseReference= FirebaseDatabase.getInstance().getReference("users");
        module=((Modul)getApplicationContext());

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Users students = dataSnapshot.child(String.valueOf(tName.getText())).getValue(Users.class);
                tName.setText(students.getName());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateArrayList();
                Cleartxt();
                Intent intphto =new Intent(getApplicationContext(),Login.class);
                startActivity(intphto);


            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cleartxt();
            }
        });
    }
    private void Cleartxt(){
        tName.setText("");
        tPassword.setText("");
        tConfirmPassword.setText("");
        result.setText("");

    }

    private void  updateArrayList() {
        final String name = tName.getText().toString().trim();
        final String password = tPassword.getText().toString().trim();
        String comfirmpassword = tConfirmPassword.getText().toString().trim();
        String resulthash = result.getText().toString().trim();
         if (TextUtils.isEmpty(name)) {
            tName.setError("Lütfen İsminizi Girin!");
        } else if (TextUtils.isEmpty(password)) {
            tPassword.setError("Lütfen Şifrenizi Girin!");
        } else if (!password.equals(comfirmpassword)) {
            tConfirmPassword.setError("Lütfen aynı şifreyi girin!!!");
        } else {

            Users students = new Users(name, password);
            databaseReference.child("users").child(name).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    databaseReference = FirebaseDatabase.getInstance().getReference();
                    databaseReference.child("users").child(name).child("name").setValue(name);
                    try {
                        databaseReference.child("users").child(name).child("password").setValue(Guvenlik.encrypt(password));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            Toast.makeText(this, "Şifre Değiştirildi", Toast.LENGTH_LONG).show();
            Cleartxt();

        }
    }
}
