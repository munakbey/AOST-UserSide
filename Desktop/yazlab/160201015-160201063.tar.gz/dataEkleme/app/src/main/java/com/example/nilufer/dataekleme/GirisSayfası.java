package com.example.nilufer.dataekleme;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.location.Address;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nilufer.dataekleme.Bildirim.NotificationService;

public class GirisSayfası extends AppCompatActivity {

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    AddressResultReceiver mResultReceiver;
    EditText threshold, kategori;
    String aralık;
    String filtre;

    EditText latitudeEdit, longitudeEdit, addressEdit;
    TextView infoText;
    CheckBox checkBox;
    Button fetch;
    RadioGroup rdB;

    boolean fetchAddress;
    int fetchType = Constants.USE_ADDRESS_LOCATION;
    boolean gps = false;

    private static final String TAG = "GirisSayfası";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa);

        threshold = (EditText) findViewById(R.id.threshold);
        kategori = (EditText) findViewById(R.id.kategori);

        longitudeEdit = (EditText) findViewById(R.id.longitudeEdit);
        latitudeEdit = (EditText) findViewById(R.id.latitudeEdit);
        addressEdit = (EditText) findViewById(R.id.adress);
        infoText = (TextView) findViewById(R.id.infoText);
        checkBox = (CheckBox) findViewById(R.id.checkbox);
        fetch = (Button) findViewById(R.id.search);
        rdB = (RadioGroup) findViewById(R.id.radioGroup);

        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClicked(view);
            }
        });
        rdB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onRadioButtonClicked(view);
            }
        });
        mResultReceiver = new AddressResultReceiver(null);

    }



    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();

        switch(view.getId()) {
            case R.id.radioAddress:
                if (checked) {
                    fetchAddress = false;
                    fetchType = Constants.USE_ADDRESS_NAME;
                    longitudeEdit.setEnabled(false);
                    latitudeEdit.setEnabled(false);
                    addressEdit.setEnabled(true);
                    addressEdit.requestFocus();
                }
                break;
            case R.id.radioLocation:
                if (checked) {
                    fetchAddress = true;
                    fetchType = Constants.USE_ADDRESS_LOCATION;
                    latitudeEdit.setEnabled(true);
                    latitudeEdit.requestFocus();
                    longitudeEdit.setEnabled(true);
                    addressEdit.setEnabled(false);
                }
                break;
            case R.id.gpsRadio:
                if (checked) {
                    gps = true;
                }
                break;
        }
    }

    private void getLocation() {

        String lattitude,longitude;


        if (ActivityCompat.checkSelfPermission(GirisSayfası.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (GirisSayfası.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(GirisSayfası.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        } else {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            Location location1 = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            Location location2 = locationManager.getLastKnownLocation(LocationManager. PASSIVE_PROVIDER);

            if (location != null) {
                double latti = location.getLatitude();
                double longi = location.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                aralık = threshold.getText().toString().trim();
                System.out.println("aralık :"+aralık);
                filtre = kategori.getText().toString().trim();

                Intent intphto = new Intent(getApplicationContext(), fGosterim.class);
                System.out.println("GPS---Giris lat :"+lattitude);
                intphto.putExtra("kategori",filtre);
                intphto.putExtra("lat",latti);
                intphto.putExtra("long",longi);
                intphto.putExtra("threshold",Double.valueOf(aralık));

                startActivity(intphto);


            } else  if (location1 != null) {
                double latti = location1.getLatitude();
                double longi = location1.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                aralık = threshold.getText().toString().trim();
                System.out.println("aralık :"+aralık);
                filtre = kategori.getText().toString().trim();


                Intent intphto = new Intent(getApplicationContext(), fGosterim.class);
                System.out.println("GPS---Giris lat :"+lattitude);
                intphto.putExtra("kategori",filtre);
                intphto.putExtra("lat",latti);
                intphto.putExtra("long",longi);
                intphto.putExtra("threshold",Double.valueOf(aralık));

                startActivity(intphto);


            } else  if (location2 != null) {
                double latti = location2.getLatitude();
                double longi = location2.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                aralık = threshold.getText().toString().trim();
                System.out.println("aralık :"+aralık);
                filtre = kategori.getText().toString().trim();
                System.out.println("lat :"+latti+"long"+longi+"threshold : "+aralık);

                Intent intphto = new Intent(getApplicationContext(), fGosterim.class);
                System.out.println("GPS---Giris lat :"+lattitude);
                System.out.println("threshold giris :" + Integer.valueOf(aralık));
                intphto.putExtra("kategori",filtre);
                intphto.putExtra("lat",latti);
                intphto.putExtra("long",longi);
                intphto.putExtra("threshold",Double.valueOf(aralık));

                startActivity(intphto);

            }else{

                Toast.makeText(GirisSayfası.this,"Unble to Trace your location",Toast.LENGTH_SHORT).show();
                gps = false;

            }
        }
    }


    public void onButtonClicked(View view) {
        Intent intent = new Intent(this, GeocodeAddressIntentService.class);
        intent.putExtra(Constants.RECEIVER, mResultReceiver);
        intent.putExtra(Constants.FETCH_TYPE_EXTRA, fetchType);

        if (threshold.getText().length() == 0) {

            Toast.makeText(this,
                    "Konum aralığı giriniz!",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (gps == true)
        {
            getLocation();
        }else{
        if(fetchType == Constants.USE_ADDRESS_NAME) {
            if(addressEdit.getText().length() == 0) {
                Toast.makeText(this, "Please enter an address name", Toast.LENGTH_LONG).show();
                return;
            }
            intent.putExtra(Constants.LOCATION_NAME_DATA_EXTRA, addressEdit.getText().toString());


        }
        else {
            if(latitudeEdit.getText().length() == 0 || longitudeEdit.getText().length() == 0) {
                Toast.makeText(this,
                        "Lat ve Long değerlerini girin",
                        Toast.LENGTH_LONG).show();
                return;
            }
            intent.putExtra(Constants.LOCATION_LATITUDE_DATA_EXTRA,
                    Double.parseDouble(latitudeEdit.getText().toString()));
            intent.putExtra(Constants.LOCATION_LONGITUDE_DATA_EXTRA,
                    Double.parseDouble(longitudeEdit.getText().toString()));
            intent.putExtra(Constants.LOCATION_LONGITUDE_DATA_EXTRA,
                    Double.parseDouble(longitudeEdit.getText().toString()));

        }
        infoText.setVisibility(View.INVISIBLE);
        Log.e(TAG, "Servis başlatılıyor");
        startService(intent);

        }

    }


    class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, final Bundle resultData) {
            if (resultCode == Constants.SUCCESS_RESULT) {
                final Address address = resultData.getParcelable(Constants.RESULT_ADDRESS);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        infoText.setVisibility(View.VISIBLE);
                        infoText.setText("Latitude: " + address.getLatitude() + "\n" +
                                "Longitude: " + address.getLongitude() + "\n" +
                                "Address: " + resultData.getString(Constants.RESULT_DATA_KEY));
                        aralık = threshold.getText().toString().trim();
                        System.out.println("aralık :"+aralık);
                        filtre = kategori.getText().toString().trim();


                        Intent intphto = new Intent(getApplicationContext(), fGosterim.class);
                        System.out.println("Giris lat :"+address.getLatitude());
                        System.out.println("threshold giris :" + Integer.valueOf(aralık));
                        intphto.putExtra("kategori",filtre);
                        intphto.putExtra("lat",address.getLatitude());
                        intphto.putExtra("long",address.getLongitude());
                        intphto.putExtra("threshold",Double.valueOf(aralık));

                        startActivity(intphto);
                    }
                });

            }
            else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        infoText.setVisibility(View.VISIBLE);
                        infoText.setText(resultData.getString(Constants.RESULT_DATA_KEY));
                    }
                });
            }
        }
    }
}
