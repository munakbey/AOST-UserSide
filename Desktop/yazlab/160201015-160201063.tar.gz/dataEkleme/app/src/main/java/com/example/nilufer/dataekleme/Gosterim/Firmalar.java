package com.example.nilufer.dataekleme.Gosterim;

public class Firmalar {
    private String firmaid;
    private String firmaAdi;
    private String firmaLokasyon;
    private String kampanyaIcerik;
    private int kampanyaSuresi;

    public Firmalar(String firmaid, String firmaAdi, String firmaLokasyon, String kampanyaIcerik, int kampanyaSuresi) {
        this.firmaid = firmaid;
        this.firmaAdi = firmaAdi;
        this.firmaLokasyon = firmaLokasyon;
        this.kampanyaIcerik = kampanyaIcerik;
        this.kampanyaSuresi = kampanyaSuresi;
    }

    public String getFirmaid() {
        return firmaid;
    }

    public void setFirmaid(String firmaid) {
        this.firmaid = firmaid;
    }

    public String getFirmaAdi() {
        return firmaAdi;
    }

    public void setFirmaAdi(String firmaAdi) {
        this.firmaAdi = firmaAdi;
    }

    public String getFirmaLokasyon() {
        return firmaLokasyon;
    }

    public void setFirmaLokasyon(String firmaLokasyon) {
        this.firmaLokasyon = firmaLokasyon;
    }

    public String getKampanyaIcerik() {
        return kampanyaIcerik;
    }

    public void setKampanyaIcerik(String kampanyaIcerik) {
        this.kampanyaIcerik = kampanyaIcerik;
    }

    public int getKampanyaSuresi() {
        return kampanyaSuresi;
    }

    public void setKampanyaSuresi(int kampanyaSuresi) {
        this.kampanyaSuresi = kampanyaSuresi;
    }
}
