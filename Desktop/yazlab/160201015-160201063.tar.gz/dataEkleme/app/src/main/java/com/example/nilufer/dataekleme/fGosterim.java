package com.example.nilufer.dataekleme;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.nilufer.dataekleme.Bildirim.NotificationService;
import com.example.nilufer.dataekleme.Gosterim.FirmaAdapter;
import com.example.nilufer.dataekleme.Gosterim.Firmalar;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class fGosterim extends AppCompatActivity {

    private static final String TAG = "fGosterim";

    private RecyclerView mList;
    private TextView kategori;
    String flt;
    private ArrayList adres;
    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private List<Firmalar> firmalarList;
    private List<Double> uzunluklar ;
    private RecyclerView.Adapter adapter;
    private String url = "https://us-central1-api1-13f97.cloudfunctions.net/getItems";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fgosterim);

        mList = findViewById(R.id.recyclerView);

        firmalarList = new ArrayList<>();
        mList.setAdapter(adapter);

        adapter = new FirmaAdapter(getApplicationContext(),firmalarList);


        mList.setAdapter(adapter);
        adapter = new FirmaAdapter(getApplicationContext(),firmalarList);

        if (getIntent().hasExtra("kategori" )){
            flt =getIntent().getStringExtra("kategori");

        }

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(mList.getContext(), linearLayoutManager.getOrientation());

        mList.setHasFixedSize(true);
        mList.setLayoutManager(linearLayoutManager);
        mList.addItemDecoration(dividerItemDecoration);
        mList.setAdapter(adapter);

        getDoubleExtras();


    }
    private void getData(final Double lat, final Double aLong, final Double threshold) {


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new com.android.volley.Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        try {
                            List<Firmalar> firma =new ArrayList<Firmalar>();
                            adres =new ArrayList();
                            LatLng uzun = null;
                          JSONArray array=new JSONArray(response);
                            for (int i=0;i<array.length();i++)
                            {


                                JSONObject object=array.getJSONObject(i);
                                Firmalar firmalar=new Firmalar(object.getString("firmaId"),object.getString("firmaAdi"),
                                        object.getString("firmaLokasyon"),object.getString("kampanyaIcerigi"),object.getInt("kampanyaSuresi")
                                );


                                System.out.println("flt : "+flt);
                                if(flt != null && flt.equalsIgnoreCase(object.getString("kampanyaIcerigi"))){
                                    uzun =gps( object.getString("firmaLokasyon"));
                                    Double lt = uzun.latitude;
                                    Double lng = uzun.longitude;
                                    double ms =addressCalculation(lat,aLong,lt,lng);
                                    System.out.println("uzunluk(ms) :"+ms+"threshold :"+threshold);
                                    if (ms <= threshold){
                                        firmalarList.add(firmalar);
                                        firma.add(firmalar);
                                    }


                                }else if(flt == null || flt.isEmpty()){
                                    uzun =gps( object.getString("firmaLokasyon"));
                                    Double lt = uzun.latitude;
                                    Double lng = uzun.longitude;
                                    double ms =addressCalculation(lat,aLong,lt,lng);
                                    System.out.println("uzunluk(ms) :"+ms);
                                    if (ms <= threshold){
                                        firmalarList.add(firmalar);
                                        firma.add(firmalar);

                                    }

                                }

                                adapter.notifyDataSetChanged();

                            }
                            Intent intent = new Intent(getApplicationContext(), NotificationService.class);
                            intent.putExtra("lat", lat);
                            intent.putExtra("long", aLong);
                            intent.putExtra("threshold", threshold);
                            intent.putExtra("kategori", flt);
                            startService(intent);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public LatLng gps( String strAddress) {

        Geocoder coder = new Geocoder(this);
        List<Address> address;
        LatLng k = null;

        try {
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }

            Address location = address.get(0);
            k = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }


        return k;
    }

    private void getDoubleExtras()
    {
        Double lat=getIntent().getDoubleExtra("lat",0);
        Double aLong=getIntent().getDoubleExtra("long",0);
        Double threshold=getIntent().getDoubleExtra("threshold",0);
        System.out.println("lat :"+lat+"long"+aLong+"threshold : "+threshold);
        getData(lat,aLong,threshold);

    }
    private double addressCalculation(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;

        dist = dist * 1.609344;

        return (dist);
    }


    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }




}