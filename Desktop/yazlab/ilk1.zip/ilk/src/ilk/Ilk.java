/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ilk;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author HP
 */
public class Ilk extends JFrame{

 
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
  FileInputStream fis = new FileInputStream("aa.jpg");
  BufferedImage image = ImageIO.read(fis);
 
  int satir = 4;
  int kolon = 4;
  int resimSayisi = satir * kolon;
 
  int yeniResimGenislik = image.getWidth() / kolon;
  int yeniResimYukseklik = image.getHeight() / satir;
  int resimNo = 0;
  BufferedImage imgs[] = new BufferedImage[resimSayisi];
  BufferedImage imgk[] = new BufferedImage[resimSayisi];
  for (int x = 0; x < satir; x++) {
   for (int y = 0; y < kolon; y++) {
    imgs[resimNo] = new BufferedImage(yeniResimGenislik, yeniResimYukseklik, 1);
 
    Graphics2D gr = imgs[resimNo++].createGraphics();
    gr.drawImage(image, 0, 0, yeniResimGenislik, yeniResimYukseklik, yeniResimGenislik
      * y, yeniResimYukseklik * x, yeniResimGenislik * y + yeniResimGenislik,
      yeniResimYukseklik * x + yeniResimYukseklik, null);
    gr.dispose();
   }
  } 
  
  JFrame frame=new JFrame("puzzle");
  JPanel panel=new JPanel();
  panel.setLayout(null);
  panel.setSize(100,80);
  panel.setLocation(150,150);
  ImageIcon imageIcon0 = new ImageIcon(imgs[0]);
  ImageIcon imageIcon1 = new ImageIcon(imgs[1]);
  ImageIcon imageIcon2 = new ImageIcon(imgs[2]);
  ImageIcon imageIcon3 = new ImageIcon(imgs[3]);
  ImageIcon imageIcon4 = new ImageIcon(imgs[4]);
  ImageIcon imageIcon5 = new ImageIcon(imgs[5]);
  ImageIcon imageIcon6 = new ImageIcon(imgs[6]);
  ImageIcon imageIcon7 = new ImageIcon(imgs[7]);
  ImageIcon imageIcon8 = new ImageIcon(imgs[8]);
  ImageIcon imageIcon9 = new ImageIcon(imgs[9]);
  ImageIcon imageIcon10 = new ImageIcon(imgs[10]);
  ImageIcon imageIcon11 = new ImageIcon(imgs[11]);
  ImageIcon imageIcon12 = new ImageIcon(imgs[12]);
  ImageIcon imageIcon13 = new ImageIcon(imgs[13]);
  ImageIcon imageIcon14 = new ImageIcon(imgs[14]);
  ImageIcon imageIcon15 = new ImageIcon(imgs[15]);
  
  JButton jb0=new JButton(imageIcon0);
  jb0.setSize(150,200);
  jb0.setLocation(100,100);
  jb0.setHorizontalAlignment(0);
  panel.add(jb0);
  
  JButton jb1=new JButton(imageIcon1);
  jb1.setSize(150,200);
  jb1.setLocation(260,100);
  jb1.setHorizontalAlignment(0);
  panel.add(jb1);
  
  JButton jb2=new JButton(imageIcon2);
  jb2.setSize(150,200);
  jb2.setLocation(420,100);
  jb2.setHorizontalAlignment(0);
  panel.add(jb2);
  
  JButton jb3=new JButton(imageIcon3);
  jb3.setSize(150,200);
  jb3.setLocation(580,100);
  jb3.setHorizontalAlignment(0);
  panel.add(jb3);
  
  JButton jb4=new JButton(imageIcon4);
  jb4.setSize(150,200);
  jb4.setLocation(100,310);
  jb4.setHorizontalAlignment(0);
  panel.add(jb4);
  
  JButton jb5=new JButton(imageIcon5);
  jb5.setSize(150,200);
  jb5.setLocation(260,310);
  jb5.setHorizontalAlignment(0);
  panel.add(jb5);
  
  JButton jb6=new JButton(imageIcon6);
  jb6.setSize(150,200);
  jb6.setLocation(420,310);
  jb6.setHorizontalAlignment(0);
  panel.add(jb6);
  
  JButton jb7=new JButton(imageIcon7);
  jb7.setSize(150,200);
  jb7.setLocation(580,310);
  jb7.setHorizontalAlignment(0);
  panel.add(jb7);
  
  JButton jb8=new JButton(imageIcon8);
  jb8.setSize(150,200);
  jb8.setLocation(100,520);
  jb8.setHorizontalAlignment(0);
  panel.add(jb8);
  
  JButton jb9=new JButton(imageIcon9);
  jb9.setSize(150,200);
  jb9.setLocation(260,520);
  jb9.setHorizontalAlignment(0);
  panel.add(jb9);
  
  JButton jb10=new JButton(imageIcon10);
  jb10.setSize(150,200);
  jb10.setLocation(420,520);
  jb10.setHorizontalAlignment(0);
  panel.add(jb10);
  
  JButton jb11=new JButton(imageIcon11);
  jb11.setSize(150,200);
  jb11.setLocation(580,520);
  jb11.setHorizontalAlignment(0);
  panel.add(jb11);
  
  JButton jb12=new JButton(imageIcon12);
  jb12.setSize(150,200);
  jb12.setLocation(100,740);
  jb12.setHorizontalAlignment(0);
  panel.add(jb12);
  
  JButton jb13=new JButton(imageIcon13);
  jb13.setSize(150,200);
  jb13.setLocation(260,740);
  jb13.setHorizontalAlignment(0);
  panel.add(jb13);
  
  JButton jb14=new JButton(imageIcon14);
  jb14.setSize(150,200);
  jb14.setLocation(420,740);
  jb14.setHorizontalAlignment(0);
  panel.add(jb14);
  
  JButton jb15=new JButton(imageIcon15);
  jb15.setSize(150,200);
  jb15.setLocation(580,740);
  jb15.setHorizontalAlignment(0);
  panel.add(jb15);
  
    JButton jby=new JButton();
  jby.setText("KARİSİTİR");
  jby.setSize(200,100);
  jby.setLocation(800,400);
  jby.setHorizontalAlignment(0);
  jby.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        
Random rnd = new Random(); 
int[] dizim = new int[16];
int yeni_sayi; 
Boolean durum = true;

for (int i = 0; i < dizim.length; i++)
{
while (durum)
{
yeni_sayi = rnd.nextInt(16);

if (i == 0)
{
dizim[0] = yeni_sayi;
break; 
}
for (int k = 0; k < i; k++)
{
if (dizim[k] == yeni_sayi) 
{
durum = true;
break; 
}
else
durum = false;
}
if (durum == false)
dizim[i] = yeni_sayi;
}
durum = true;
}
for(int i=0;i<dizim.length;i++)
{
    System.out.print(" "+dizim[i]);
}


for(int i=0;i<imgk.length;i++)
  {
      imgk[i]=imgs[dizim[i]];
  }


  ImageIcon imageIcon0 = new ImageIcon(imgk[0]);
  ImageIcon imageIcon1 = new ImageIcon(imgk[1]);
  ImageIcon imageIcon2 = new ImageIcon(imgk[2]);
  ImageIcon imageIcon3 = new ImageIcon(imgk[3]);
  ImageIcon imageIcon4 = new ImageIcon(imgk[4]);
  ImageIcon imageIcon5 = new ImageIcon(imgk[5]);
  ImageIcon imageIcon6 = new ImageIcon(imgk[6]);
  ImageIcon imageIcon7 = new ImageIcon(imgk[7]);
  ImageIcon imageIcon8 = new ImageIcon(imgk[8]);
  ImageIcon imageIcon9 = new ImageIcon(imgk[9]);
  ImageIcon imageIcon10 = new ImageIcon(imgk[10]);
  ImageIcon imageIcon11 = new ImageIcon(imgk[11]);
  ImageIcon imageIcon12 = new ImageIcon(imgk[12]);
  ImageIcon imageIcon13 = new ImageIcon(imgk[13]);
  ImageIcon imageIcon14 = new ImageIcon(imgk[14]);
  ImageIcon imageIcon15 = new ImageIcon(imgk[15]);
  
  
  //JButton jb0=new JButton();
  jb0.setIcon(imageIcon0);
  jb0.setSize(150,200);
  jb0.setLocation(100,100);
  jb0.setHorizontalAlignment(0);
  panel.add(jb0);
  
  //JButton jb1=new JButton(imageIcon17);
  jb1.setIcon(imageIcon1);
  jb1.setSize(150,200);
  jb1.setLocation(260,100);
  jb1.setHorizontalAlignment(0);
  panel.add(jb1);
  
  //JButton jb2=new JButton(imageIcon2);
  jb2.setIcon(imageIcon2);
  jb2.setSize(150,200);
  jb2.setLocation(420,100);
  jb2.setHorizontalAlignment(0);
  panel.add(jb2);
  
  //JButton jb3=new JButton(imageIcon3);
  jb3.setIcon(imageIcon3);
  jb3.setSize(150,200);
  jb3.setLocation(580,100);
  jb3.setHorizontalAlignment(0);
  panel.add(jb3);
  
  //JButton jb4=new JButton(imageIcon4);
  jb4.setIcon(imageIcon4);
  jb4.setSize(150,200);
  jb4.setLocation(100,310);
  jb4.setHorizontalAlignment(0);
  panel.add(jb4);
  
  //JButton jb5=new JButton(imageIcon5);
  jb5.setIcon(imageIcon5);
  jb5.setSize(150,200);
  jb5.setLocation(260,310);
  jb5.setHorizontalAlignment(0);
  panel.add(jb5);
  
  //JButton jb6=new JButton(imageIcon6);
  jb6.setIcon(imageIcon6);
  jb6.setSize(150,200);
  jb6.setLocation(420,310);
  jb6.setHorizontalAlignment(0);
  panel.add(jb6);
  
  //JButton jb7=new JButton(imageIcon7);
  jb7.setIcon(imageIcon7);
  jb7.setSize(150,200);
  jb7.setLocation(580,310);
  jb7.setHorizontalAlignment(0);
  panel.add(jb7);
  
  //JButton jb8=new JButton(imageIcon8);
  jb8.setIcon(imageIcon8);
  jb8.setSize(150,200);
  jb8.setLocation(100,520);
  jb8.setHorizontalAlignment(0);
  panel.add(jb8);
  
  //JButton jb9=new JButton(imageIcon9);
  jb9.setIcon(imageIcon9);
  jb9.setSize(150,200);
  jb9.setLocation(260,520);
  jb9.setHorizontalAlignment(0);
  panel.add(jb9);
  
  //JButton jb10=new JButton(imageIcon10);
  jb10.setIcon(imageIcon10);
  jb10.setSize(150,200);
  jb10.setLocation(420,520);
  jb10.setHorizontalAlignment(0);
  panel.add(jb10);
  
  //JButton jb11=new JButton(imageIcon11);
  jb11.setIcon(imageIcon11);
  jb11.setSize(150,200);
  jb11.setLocation(580,520);
  jb11.setHorizontalAlignment(0);
  panel.add(jb11);
  
  //JButton jb12=new JButton(imageIcon12);
  jb12.setIcon(imageIcon12);
  jb12.setSize(150,200);
  jb12.setLocation(100,740);
  jb12.setHorizontalAlignment(0);
  panel.add(jb12);
  
  //JButton jb13=new JButton(imageIcon13);
  jb13.setIcon(imageIcon13);
  jb13.setSize(150,200);
  jb13.setLocation(260,740);
  jb13.setHorizontalAlignment(0);
  panel.add(jb13);
  
  //JButton jb14=new JButton(imageIcon14);
  jb14.setIcon(imageIcon14);
  jb14.setSize(150,200);
  jb14.setLocation(420,740);
  jb14.setHorizontalAlignment(0);
  panel.add(jb14);
  
  //JButton jb15=new JButton(imageIcon15);
  jb15.setIcon(imageIcon15);
  jb15.setSize(150,200);
  jb15.setLocation(580,740);
  jb15.setHorizontalAlignment(0);
  panel.add(jb15);



    }
});
  panel.add(jby);
  
  frame.setContentPane(panel);
  frame.setSize(5000, 5000);
  frame.setLocation(200,250);
  frame.setVisible(true);
    
//System.out.println("Resim parcalandi");
 /*
  // Resimler dosyaya yaziliyor.
  for (int i = 0; i < imgs.length; i++) {
   ImageIO.write(imgs[i], "jpg", new File("img" + i + ".jpg"));
  }
  System.out.println("Islem tamamlandi");*/
    }
    
}
