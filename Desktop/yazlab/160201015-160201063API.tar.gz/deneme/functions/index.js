const functions = require("firebase-functions");
const cors = require('cors')({ origin: true });
const admin = require('firebase-admin');

admin.initializeApp();

const database = admin.database().ref('/firmalar');

exports.helloWorld = functions.https.onRequest((request, response) => {
  response.send("Uygulamamıza Hoşgeldiniz!");
});


exports.addItem = functions.https.onRequest((req, res) => {
  return cors(req, res, () => {
    if(req.method !== 'POST') {
      return res.status(401).json({
        message: 'Not allowed'
      })
    }
    let item = [];	
	let id = 0;
	database.orderByKey().limitToLast(1).on('child_added',function(snapshot) {
		id =	snapshot.val().firmaId+1;

	});
  
    const firmaId = id
	const firmaAdi = req.body.firmaAdi
	const firmaLokasyon = req.body.firmaLokasyon
	const kampanyaIcerigi = req.body.kampanyaIcerigi
	const kampanyaSuresi = req.body.kampanyaSuresi
	 item.push({
		 
          firmaId,
		  firmaAdi,
		  firmaLokasyon,
		  kampanyaIcerigi,
		  kampanyaSuresi  });
		 

    database.push({ firmaId,firmaAdi,firmaLokasyon,kampanyaIcerigi,kampanyaSuresi });

    let items = [];

   	database.once("value").then(snap => {
		  snap.forEach(firmaSnap => {

		 items.push({

          firmaId: firmaSnap.val().firmaId,
		  firmaAdi: firmaSnap.val().firmaAdi,
		  firmaLokasyon: firmaSnap.val().firmaLokasyon,
		  kampanyaIcerigi: firmaSnap.val().kampanyaIcerigi,
		  kampanyaSuresi: firmaSnap.val().kampanyaSuresi
          
			 });

		  });
     return res.status(200).json(items)

    }, (error) => {
      res.status(error.code).json({
        message: `Something went wrong. ${error.message}`
      })
    })
  })
})


exports.getItems = functions.https.onRequest((req, res) => {
  return cors(req, res, () => {
    if(req.method !== 'GET') {
      return res.status(404).json({
        message: 'Not allowed'
      })
    }

    let items = [];

	database.once("value").then(snap => {
		  snap.forEach(firmaSnap => {

		 items.push({

          firmaId: firmaSnap.val().firmaId,
		  firmaAdi: firmaSnap.val().firmaAdi,
		  firmaLokasyon: firmaSnap.val().firmaLokasyon,
		  kampanyaIcerigi: firmaSnap.val().kampanyaIcerigi,
		  kampanyaSuresi: firmaSnap.val().kampanyaSuresi
          
			 });

		  });
     return res.status(200).json(items)
	})
	
      

	  	
    }, (error) => {
      res.status(error.code).json({
        message: `Something went wrong. ${error.message}`
      })
    })
  })
